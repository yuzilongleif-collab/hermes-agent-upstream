"""Replay the 13 scoped cases on pinned official source and the complete existing PR.
No installs, Desktop launches, network requests, or user session reads.
"""
import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import tarfile
import tempfile
import time

ROOT = Path(__file__).resolve().parent
BASE = 'f30105a0b4b3d0c1baa6c464189755ccdbc1ac7f'
PATHS = ['apps/desktop', 'apps/shared', 'scripts/build', 'tests/fixtures',
         'package.json', 'package-lock.json', 'eslint.config.shared.mjs']
PRODUCTION = ['apps/desktop/src/app/session/hooks/use-session-actions/index.ts',
              'apps/desktop/src/app/session/hooks/use-session-actions/persisted-live-turn.ts',
              'apps/desktop/src/lib/chat-messages/coverage.ts']
SELECTION = ['src/app/session/hooks/use-session-actions.test.tsx',
             'src/app/session/hooks/use-session-actions/commentary-case-repro.test.ts',
             'src/app/session/hooks/use-session-actions/cached-commentary-case-repro.test.ts']
PATTERN = 'empty snapshot: true|reconcile cached commentary|control:|Codex commentary'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, type=Path, help='existing official Git object store; read-only')
    parser.add_argument('--deps', required=True, type=Path, help='compatible monorepo dependencies; no installation')
    parser.add_argument('--node', required=True, type=Path, help='Node >=26 executable')
    parser.add_argument('--out', required=True, type=Path)
    args = parser.parse_args()
    args.source = args.source.resolve(); args.deps = args.deps.resolve(); args.node = args.node.resolve()
    args.out = args.out.resolve(); args.out.mkdir(parents=True, exist_ok=True)
    source_env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
    identity = json.loads((ROOT/'source-identity.json').read_text())
    for name, digest in identity['patches'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest() == digest
    archive = subprocess.check_output(['git', '-C', str(args.source), 'archive', BASE, *PATHS], env=source_env)
    report = {'baseline': BASE, 'pr_head': identity['pr_head'], 'runs': []}
    with tempfile.TemporaryDirectory(prefix='replay-', dir=ROOT) as tmp:
        work = Path(tmp)/'source'; work.mkdir()
        with tarfile.open(fileobj=io.BytesIO(archive)) as tf:
            tf.extractall(work, filter='data')
        before = {p:(work/p).read_bytes() for p in PRODUCTION}
        for path, body in before.items():
            assert hashlib.sha256(body).hexdigest() == identity['source']['baseline:'+path]
        for name in ['integrated-original-pr.patch', 'new-regressions.patch']:
            subprocess.run(['git','apply','--check',str(ROOT/name)],cwd=work,check=True)
            subprocess.run(['git','apply',str(ROOT/name)],cwd=work,check=True)
        candidate = {p:(work/p).read_bytes() for p in PRODUCTION}
        for path, body in candidate.items():
            assert hashlib.sha256(body).hexdigest() == identity['source']['candidate:'+path]
        assert hashlib.sha256((work/'apps/desktop/src/app/session/hooks/use-session-actions.test.tsx').read_bytes()).hexdigest() == identity['test_hook_sha256']
        for rel in ['node_modules','apps/desktop/node_modules']:
            target=work/rel; target.mkdir(exist_ok=True)
            for package in (args.deps/rel).iterdir():
                if not package.name.startswith('.'):
                    (target/package.name).symlink_to(package)
        home=work/'.test-home'; temp=work/'.test-tmp'; home.mkdir(); temp.mkdir()
        env={k:v for k,v in os.environ.items() if k in ['PATH','LANG','LC_ALL','SYSTEMROOT']}
        env.update(HOME=str(home),HERMES_HOME=str(home),TMPDIR=str(temp),TEMP=str(temp),TMP=str(temp),
                   HERMES_DISABLE_LAZY_INSTALLS='1',CI='1',NO_COLOR='1',NODE_ENV='development')
        for mode in ['baseline','candidate']:
            for path, body in (before if mode=='baseline' else candidate).items():
                (work/path).write_bytes(body)
            cmd=[str(args.node),str(work/'node_modules/vitest/vitest.mjs'),'run','--project','ui',
                 '--configLoader','runner','--no-cache','--maxWorkers','1','--no-file-parallelism',
                 '--reporter=verbose','--reporter=json','--outputFile.json='+str(args.out/(mode+'.json')),
                 *SELECTION,'--testNamePattern',PATTERN]
            started=time.monotonic()
            with (args.out/(mode+'.log')).open('w') as log:
                process=subprocess.Popen(cmd,cwd=work/'apps/desktop',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
                try:
                    status=process.wait(timeout=300)
                finally:
                    if process.poll() is None:
                        os.killpg(process.pid,signal.SIGTERM)
                        try: process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            os.killpg(process.pid,signal.SIGKILL); process.wait()
            doc=json.loads((args.out/(mode+'.json')).read_text())
            cases=[a for f in doc['testResults'] for a in f['assertionResults'] if a['status'] not in ['pending','skipped']]
            counts={s:sum(a['status']==s for a in cases) for s in ['passed','failed']}
            report['runs'].append({'mode':mode,'exit':status,'cases':len(cases),**counts,'seconds':time.monotonic()-started})
            print(mode,status,counts,flush=True)
            assert len(cases)==13
            assert (counts['failed'],counts['passed'],status)==((10,3,1) if mode=='baseline' else (0,13,0))
        report['fixture']=str(Path(tmp))
    report['fixture_removed']=not Path(report['fixture']).exists()
    assert report['fixture_removed']
    (args.out/'summary.json').write_text(json.dumps(report,indent=2)+'\n')


if __name__=='__main__':
    main()
